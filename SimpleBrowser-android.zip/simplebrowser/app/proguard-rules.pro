# Правила ProGuard/R8. По умолчанию пусто — minifyEnabled выключен для release.
