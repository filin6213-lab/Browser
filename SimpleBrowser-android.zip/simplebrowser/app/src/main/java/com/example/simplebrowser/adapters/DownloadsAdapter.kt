package com.example.simplebrowser.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.simplebrowser.R
import com.example.simplebrowser.data.DownloadItem

class DownloadsAdapter(
    private var items: List<DownloadItem>
) : RecyclerView.Adapter<DownloadsAdapter.ViewHolder>() {

    class ViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.downloadTitle)
        val status: TextView = view.findViewById(R.id.downloadStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_download, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.title.text = item.fileName
        holder.status.text = item.status
    }

    override fun getItemCount(): Int = items.size

    fun update(newItems: List<DownloadItem>) {
        items = newItems
        notifyDataSetChanged()
    }
}
