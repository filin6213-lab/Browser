package com.example.simplebrowser.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.simplebrowser.R
import com.example.simplebrowser.data.Bookmark

// Строка списка закладок: либо заголовок папки, либо сама закладка
sealed class BookmarkRow {
    data class Header(val folder: String) : BookmarkRow()
    data class Item(val bookmark: Bookmark) : BookmarkRow()
}

class BookmarksAdapter(
    private var rows: List<BookmarkRow>,
    private val onClick: (Bookmark) -> Unit,
    private val onDelete: (Bookmark) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TYPE_HEADER = 0
        private const val TYPE_ITEM = 1
    }

    class HeaderViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val text: TextView = view.findViewById(R.id.folderHeaderText)
    }

    class ItemViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.itemTitle)
        val url: TextView = view.findViewById(R.id.itemSubtitle)
        val delete: ImageButton = view.findViewById(R.id.itemDelete)
    }

    override fun getItemViewType(position: Int): Int =
        if (rows[position] is BookmarkRow.Header) TYPE_HEADER else TYPE_ITEM

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == TYPE_HEADER) {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_folder_header, parent, false)
            HeaderViewHolder(view)
        } else {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_list_row, parent, false)
            ItemViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = rows[position]) {
            is BookmarkRow.Header -> {
                (holder as HeaderViewHolder).text.text = row.folder
            }
            is BookmarkRow.Item -> {
                val vh = holder as ItemViewHolder
                vh.title.text = row.bookmark.title.ifBlank { row.bookmark.url }
                vh.url.text = row.bookmark.url
                vh.itemView.setOnClickListener { onClick(row.bookmark) }
                vh.delete.setOnClickListener { onDelete(row.bookmark) }
            }
        }
    }

    override fun getItemCount(): Int = rows.size

    fun update(newRows: List<BookmarkRow>) {
        rows = newRows
        notifyDataSetChanged()
    }
}
