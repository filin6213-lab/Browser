package com.example.simplebrowser

import android.content.Context

object Prefs {
    private const val PREFS_NAME = "simple_browser_prefs"
    private const val KEY_SEARCH_ENGINE = "search_engine"
    private const val KEY_THEME = "theme"
    private const val KEY_JS_ENABLED = "js_enabled"
    private const val KEY_SAVE_HISTORY = "save_history"
    private const val KEY_BLOCK_POPUPS = "block_popups"

    const val ENGINE_GOOGLE = "google"
    const val ENGINE_DUCKDUCKGO = "duckduckgo"
    const val ENGINE_STARTPAGE = "startpage"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getSearchEngine(context: Context): String =
        prefs(context).getString(KEY_SEARCH_ENGINE, ENGINE_GOOGLE) ?: ENGINE_GOOGLE

    fun setSearchEngine(context: Context, engine: String) {
        prefs(context).edit().putString(KEY_SEARCH_ENGINE, engine).apply()
    }

    // Обычный поиск из адресной строки
    fun buildSearchUrl(context: Context, query: String): String {
        val encoded = java.net.URLEncoder.encode(query, "UTF-8")
        return when (getSearchEngine(context)) {
            ENGINE_DUCKDUCKGO -> "https://duckduckgo.com/?q=$encoded"
            ENGINE_STARTPAGE -> "https://www.startpage.com/sp/search?query=$encoded"
            else -> "https://www.google.com/search?q=$encoded"
        }
    }

    // action/param для HTML-формы поиска на домашней странице — реально ведёт на выбранный поисковик
    fun searchFormAction(context: Context): String = when (getSearchEngine(context)) {
        ENGINE_DUCKDUCKGO -> "https://duckduckgo.com/"
        ENGINE_STARTPAGE -> "https://www.startpage.com/sp/search"
        else -> "https://www.google.com/search"
    }

    fun searchFormParam(context: Context): String = when (getSearchEngine(context)) {
        ENGINE_STARTPAGE -> "query"
        else -> "q"
    }

    fun searchEngineName(context: Context): String = when (getSearchEngine(context)) {
        ENGINE_DUCKDUCKGO -> "DuckDuckGo"
        ENGINE_STARTPAGE -> "Startpage"
        else -> "Google"
    }

    fun getTheme(context: Context): String = prefs(context).getString(KEY_THEME, "blue") ?: "blue"
    fun setTheme(context: Context, theme: String) { prefs(context).edit().putString(KEY_THEME, theme).apply() }

    fun isJsEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_JS_ENABLED, true)
    fun setJsEnabled(context: Context, enabled: Boolean) { prefs(context).edit().putBoolean(KEY_JS_ENABLED, enabled).apply() }

    fun isSaveHistoryEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_SAVE_HISTORY, true)
    fun setSaveHistoryEnabled(context: Context, enabled: Boolean) { prefs(context).edit().putBoolean(KEY_SAVE_HISTORY, enabled).apply() }

    fun isBlockPopupsEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_BLOCK_POPUPS, true)
    fun setBlockPopupsEnabled(context: Context, enabled: Boolean) { prefs(context).edit().putBoolean(KEY_BLOCK_POPUPS, enabled).apply() }
}
