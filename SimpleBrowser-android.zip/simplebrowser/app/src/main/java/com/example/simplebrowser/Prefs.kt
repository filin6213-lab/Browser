package com.example.simplebrowser

import android.content.Context

object Prefs {
    private const val PREFS_NAME = "simple_browser_prefs"
    private const val KEY_SEARCH_ENGINE = "search_engine"

    const val ENGINE_GOOGLE = "google"
    const val ENGINE_DUCKDUCKGO = "duckduckgo"
    const val ENGINE_STARTPAGE = "startpage"

    fun getSearchEngine(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_SEARCH_ENGINE, ENGINE_GOOGLE) ?: ENGINE_GOOGLE
    }

    fun setSearchEngine(context: Context, engine: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_SEARCH_ENGINE, engine).apply()
    }

    // Строит URL для поиска по выбранной поисковой системе
    fun buildSearchUrl(context: Context, query: String): String {
        val encoded = java.net.URLEncoder.encode(query, "UTF-8")
        return when (getSearchEngine(context)) {
            ENGINE_DUCKDUCKGO -> "https://duckduckgo.com/?q=$encoded"
            ENGINE_STARTPAGE -> "https://www.startpage.com/sp/search?query=$encoded"
            else -> "https://www.google.com/search?q=$encoded"
        }
    }
}
