package com.example.simplebrowser

import android.graphics.Color

// primary — акцент/тулбар, background — фон окна, surface — фон панели адреса,
// inputBg/inputText — фон и текст самого поля адреса (чтобы всегда был читаемым)
data class AppTheme(
    val key: String,
    val displayName: String,
    val primary: Int,
    val background: Int,
    val surface: Int,
    val textPrimary: Int,
    val textSecondary: Int,
    val inputBg: Int,
    val inputText: Int
)

object Themes {
    val BLUE = AppTheme(
        "blue", "Синяя",
        primary = Color.parseColor("#1A73E8"),
        background = Color.parseColor("#FFFFFF"),
        surface = Color.parseColor("#F1F3F4"),
        textPrimary = Color.parseColor("#202124"),
        textSecondary = Color.parseColor("#5F6368"),
        inputBg = Color.parseColor("#FFFFFF"),
        inputText = Color.parseColor("#202124")
    )
    val DARK = AppTheme(
        "dark", "Тёмная",
        primary = Color.parseColor("#8AB4F8"),
        background = Color.parseColor("#202124"),
        surface = Color.parseColor("#2D2E30"),
        textPrimary = Color.parseColor("#E8EAED"),
        textSecondary = Color.parseColor("#9AA0A6"),
        inputBg = Color.parseColor("#3C4043"),
        inputText = Color.parseColor("#E8EAED")
    )
    val GREEN = AppTheme(
        "green", "Зелёная",
        primary = Color.parseColor("#1E8E3E"),
        background = Color.parseColor("#FFFFFF"),
        surface = Color.parseColor("#E6F4EA"),
        textPrimary = Color.parseColor("#202124"),
        textSecondary = Color.parseColor("#5F6368"),
        inputBg = Color.parseColor("#FFFFFF"),
        inputText = Color.parseColor("#202124")
    )
    val PURPLE = AppTheme(
        "purple", "Фиолетовая",
        primary = Color.parseColor("#8430CE"),
        background = Color.parseColor("#FFFFFF"),
        surface = Color.parseColor("#F3E8FD"),
        textPrimary = Color.parseColor("#202124"),
        textSecondary = Color.parseColor("#5F6368"),
        inputBg = Color.parseColor("#FFFFFF"),
        inputText = Color.parseColor("#202124")
    )
    val SUNSET = AppTheme(
        "sunset", "Закат",
        primary = Color.parseColor("#E8710A"),
        background = Color.parseColor("#FFFDF7"),
        surface = Color.parseColor("#FCE8D5"),
        textPrimary = Color.parseColor("#3C2A1E"),
        textSecondary = Color.parseColor("#8A6D5A"),
        inputBg = Color.parseColor("#FFFFFF"),
        inputText = Color.parseColor("#3C2A1E")
    )

    val ALL = listOf(BLUE, DARK, GREEN, PURPLE, SUNSET)

    fun byKey(key: String): AppTheme = ALL.find { it.key == key } ?: BLUE
}
