package com.example.simplebrowser

import android.app.DownloadManager
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.simplebrowser.adapters.DownloadsAdapter
import com.example.simplebrowser.data.AppDatabase
import com.example.simplebrowser.data.DownloadItem
import kotlinx.coroutines.launch

class DownloadsActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private lateinit var adapter: DownloadsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_downloads)

        db = AppDatabase.getInstance(this)

        val theme = Themes.byKey(Prefs.getTheme(this))
        findViewById<View>(android.R.id.content).rootView.setBackgroundColor(theme.background)
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar.setBackgroundColor(theme.primary)
        toolbar.setNavigationOnClickListener { finish() }

        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        adapter = DownloadsAdapter(emptyList())
        list.adapter = adapter

        loadDownloads()
    }

    override fun onResume() {
        super.onResume()
        loadDownloads()
    }

    private fun loadDownloads() {
        lifecycleScope.launch {
            val items = db.downloadDao().getAll()
            val refreshed = refreshStatuses(items)
            adapter.update(refreshed)
            findViewById<View>(R.id.emptyText).visibility =
                if (items.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    // Спрашиваем у системного DownloadManager реальный статус — раньше статус
    // мог зависать на "В процессе", даже если система уже закончила загрузку
    // (например, если наш BroadcastReceiver не успел сработать).
    private suspend fun refreshStatuses(items: List<DownloadItem>): List<DownloadItem> {
        val downloadManager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        val finishedText = getString(R.string.status_success)

        return items.map { item ->
            if (item.status == finishedText || item.systemDownloadId <= 0L) {
                item
            } else {
                val newStatus = queryStatus(downloadManager, item.systemDownloadId)
                if (newStatus != null && newStatus != item.status) {
                    val updated = item.copy(status = newStatus)
                    db.downloadDao().update(updated)
                    updated
                } else {
                    item
                }
            }
        }
    }

    private fun queryStatus(downloadManager: DownloadManager, systemId: Long): String? {
        val cursor = downloadManager.query(DownloadManager.Query().setFilterById(systemId))
        cursor.use {
            if (it.moveToFirst()) {
                val statusIdx = it.getColumnIndex(DownloadManager.COLUMN_STATUS)
                if (statusIdx < 0) return null
                return when (it.getInt(statusIdx)) {
                    DownloadManager.STATUS_SUCCESSFUL -> getString(R.string.status_success)
                    DownloadManager.STATUS_FAILED -> getString(R.string.status_failed)
                    DownloadManager.STATUS_PAUSED -> getString(R.string.status_paused)
                    DownloadManager.STATUS_PENDING -> getString(R.string.status_queued)
                    else -> getString(R.string.status_running)
                }
            }
        }
        // Записи нет в DownloadManager (например, после перезагрузки телефона список мог очиститься)
        return null
    }
}
