package com.example.simplebrowser

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.simplebrowser.adapters.DownloadsAdapter
import com.example.simplebrowser.data.AppDatabase
import kotlinx.coroutines.launch

class DownloadsActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private lateinit var adapter: DownloadsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_downloads)

        db = AppDatabase.getInstance(this)

        findViewById<Toolbar>(R.id.toolbar).setNavigationOnClickListener { finish() }

        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        adapter = DownloadsAdapter(emptyList())
        list.adapter = adapter

        loadDownloads()
    }

    override fun onResume() {
        super.onResume()
        loadDownloads() // обновляем статусы (Завершено/В процессе)
    }

    private fun loadDownloads() {
        lifecycleScope.launch {
            val items = db.downloadDao().getAll()
            adapter.update(items)
            findViewById<View>(R.id.emptyText).visibility =
                if (items.isEmpty()) View.VISIBLE else View.GONE
        }
    }
}
