package com.example.simplebrowser

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.simplebrowser.adapters.BookmarkRow
import com.example.simplebrowser.adapters.BookmarksAdapter
import com.example.simplebrowser.data.AppDatabase
import com.example.simplebrowser.data.Bookmark
import kotlinx.coroutines.launch

class BookmarksActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private lateinit var adapter: BookmarksAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bookmarks)

        db = AppDatabase.getInstance(this)

        val theme = Themes.byKey(Prefs.getTheme(this))
        findViewById<View>(android.R.id.content).rootView.setBackgroundColor(theme.background)
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar.setBackgroundColor(theme.primary)
        toolbar.setNavigationOnClickListener { finish() }

        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)

        adapter = BookmarksAdapter(
            emptyList(),
            onClick = { bookmark ->
                val intent = Intent(this, MainActivity::class.java)
                intent.putExtra("open_url", bookmark.url)
                intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                startActivity(intent)
                finish()
            },
            onDelete = { bookmark ->
                lifecycleScope.launch {
                    db.bookmarkDao().delete(bookmark)
                    loadBookmarks()
                }
            }
        )
        list.adapter = adapter

        loadBookmarks()
    }

    private fun loadBookmarks() {
        lifecycleScope.launch {
            val items = db.bookmarkDao().getAll() // уже отсортированы по папке на уровне SQL
            val rows = mutableListOf<BookmarkRow>()
            var currentFolder: String? = null
            for (bookmark in items) {
                if (bookmark.folder != currentFolder) {
                    currentFolder = bookmark.folder
                    rows.add(BookmarkRow.Header(bookmark.folder))
                }
                rows.add(BookmarkRow.Item(bookmark))
            }
            adapter.update(rows)
            findViewById<View>(R.id.emptyText).visibility =
                if (items.isEmpty()) View.VISIBLE else View.GONE
        }
    }
}
