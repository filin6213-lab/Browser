package com.example.simplebrowser

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.simplebrowser.adapters.BookmarksAdapter
import com.example.simplebrowser.data.AppDatabase
import kotlinx.coroutines.launch

class BookmarksActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private lateinit var adapter: BookmarksAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bookmarks)

        db = AppDatabase.getInstance(this)

        findViewById<Toolbar>(R.id.toolbar).setNavigationOnClickListener { finish() }

        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)

        adapter = BookmarksAdapter(
            emptyList(),
            onClick = { bookmark ->
                val intent = Intent(this, MainActivity::class.java)
                intent.putExtra("open_url", bookmark.url)
                intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                startActivity(intent)
                finish()
            },
            onDelete = { bookmark ->
                lifecycleScope.launch {
                    db.bookmarkDao().delete(bookmark)
                    loadBookmarks()
                }
            }
        )
        list.adapter = adapter

        loadBookmarks()
    }

    private fun loadBookmarks() {
        lifecycleScope.launch {
            val items = db.bookmarkDao().getAll()
            adapter.update(items)
            findViewById<View>(R.id.emptyText).visibility =
                if (items.isEmpty()) View.VISIBLE else View.GONE
        }
    }
}
