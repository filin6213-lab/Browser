package com.example.simplebrowser

import android.content.Context
import com.example.simplebrowser.data.Bookmark

object StartPageBuilder {
    // Фейковый базовый адрес — по нему реальный сетевой запрос никогда не уходит,
    // он нужен только для того, чтобы у WebView был "домашний" URL для истории/сравнений
    const val HOME_URL = "https://simplebrowser.home/"

    fun build(context: Context, bookmarks: List<Bookmark>): String {
        val theme = Themes.byKey(Prefs.getTheme(context))
        val action = Prefs.searchFormAction(context)
        val param = Prefs.searchFormParam(context)
        val engineName = Prefs.searchEngineName(context)

        fun hex(c: Int) = String.format("#%06X", 0xFFFFFF and c)

        val tiles = bookmarks.take(8).joinToString("") { b ->
            val label = escape((b.title.ifBlank { b.url }).take(16))
            "<a class=\"tile\" href=\"${escape(b.url)}\">$label</a>"
        }

        return """
            <!DOCTYPE html><html><head><meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <style>
                body{margin:0;font-family:sans-serif;background:${hex(theme.background)};color:${hex(theme.textPrimary)};
                    display:flex;flex-direction:column;align-items:center;padding-top:12vh;min-height:100vh;}
                h1{font-size:26px;margin:0 0 28px 0;color:${hex(theme.primary)};font-weight:600;}
                form{width:85%;max-width:480px;}
                input[type=text]{width:100%;box-sizing:border-box;padding:14px 18px;border-radius:26px;
                    border:1px solid #ddd;font-size:16px;background:#fff;color:#222;}
                .tiles{display:flex;flex-wrap:wrap;gap:10px;justify-content:center;margin-top:32px;width:90%;max-width:480px;}
                .tile{background:${hex(theme.surface)};border-radius:12px;padding:14px 8px;width:76px;
                    text-align:center;font-size:12px;color:${hex(theme.textPrimary)};text-decoration:none;
                    overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
                .hint{margin-top:18px;font-size:12px;color:${hex(theme.textSecondary)};text-align:center;padding:0 24px;}
            </style></head>
            <body>
                <h1>&#127760; Simple Browser</h1>
                <form action="$action" method="GET">
                    <input type="text" name="$param" placeholder="Поиск в $engineName" autofocus>
                </form>
                ${if (bookmarks.isEmpty()) "<div class=\"hint\">Добавь закладку (★) — она появится здесь ярлыком</div>" else ""}
                <div class="tiles">$tiles</div>
            </body></html>
        """.trimIndent()
    }

    private fun escape(s: String) = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
}
