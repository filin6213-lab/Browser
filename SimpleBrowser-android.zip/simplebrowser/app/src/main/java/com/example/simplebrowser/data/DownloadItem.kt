package com.example.simplebrowser.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Entity(tableName = "downloads")
data class DownloadItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fileName: String,
    val url: String,
    val timestamp: Long,
    val systemDownloadId: Long = -1,
    val status: String = "В процессе" // "В процессе" | "Завершено"
)

@Dao
interface DownloadDao {
    @Insert
    suspend fun insert(item: DownloadItem): Long

    @Query("SELECT * FROM downloads ORDER BY timestamp DESC")
    suspend fun getAll(): List<DownloadItem>

    @Query("UPDATE downloads SET status = :status WHERE systemDownloadId = :systemDownloadId")
    suspend fun updateStatusBySystemId(systemDownloadId: Long, status: String)

    @Update
    suspend fun update(item: DownloadItem)
}
