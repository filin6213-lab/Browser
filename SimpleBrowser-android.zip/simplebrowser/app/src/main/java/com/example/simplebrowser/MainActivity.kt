package com.example.simplebrowser

import android.Manifest
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.Patterns
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.simplebrowser.adapters.SuggestionsAdapter
import com.example.simplebrowser.data.AppDatabase
import com.example.simplebrowser.data.Bookmark
import com.example.simplebrowser.data.DEFAULT_FOLDER
import com.example.simplebrowser.data.DownloadItem
import com.example.simplebrowser.data.HistoryItem
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var addressInput: EditText
    private lateinit var pageProgress: android.widget.ProgressBar
    private lateinit var suggestionsList: androidx.recyclerview.widget.RecyclerView
    private lateinit var btnBookmarkToggle: android.widget.ImageButton
    private lateinit var topBar: View
    private lateinit var swipeRefresh: SwipeRefreshLayout

    private lateinit var db: AppDatabase
    private lateinit var suggestionsAdapter: SuggestionsAdapter

    // Данные ожидающей загрузки, пока запрашиваем разрешение (только API<=28)
    private var pendingDownload: PendingDownload? = null
    private data class PendingDownload(val url: String, val fileName: String, val userAgent: String?, val mimeType: String?)

    private var topBarHidden = false

    companion object {
        private const val REQUEST_WRITE_STORAGE = 100
        private const val HOME_URL = "https://www.google.com"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = AppDatabase.getInstance(this)

        webView = findViewById(R.id.webView)
        addressInput = findViewById(R.id.addressInput)
        pageProgress = findViewById(R.id.pageProgress)
        suggestionsList = findViewById(R.id.suggestionsList)
        btnBookmarkToggle = findViewById(R.id.btnBookmarkToggle)
        topBar = findViewById(R.id.topBar)
        swipeRefresh = findViewById(R.id.swipeRefresh)

        setupWebView()
        setupAddressBar()
        setupSuggestions()
        setupButtons()
        setupSwipeRefresh()
        setupHideOnScroll()

        val openUrl = intent?.data?.toString() ?: intent.getStringExtra("open_url")
        webView.loadUrl(openUrl ?: HOME_URL)
    }

    private fun setupWebView() {
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadWithOverviewMode = true
        webView.settings.useWideViewPort = true
        webView.settings.setSupportZoom(true)
        webView.settings.builtInZoomControls = true
        webView.settings.displayZoomControls = false
        CookieManager.getInstance().setAcceptCookie(true)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                view.loadUrl(url)
                return true
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                addressInput.setText(url)
                pageProgress.visibility = View.GONE
                swipeRefresh.isRefreshing = false
                showTopBar()
                updateBookmarkIcon(url)
                saveHistory(url, view.title ?: "")
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                if (newProgress in 1..99) {
                    pageProgress.visibility = View.VISIBLE
                    pageProgress.progress = newProgress
                } else {
                    pageProgress.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                }
            }
        }

        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED
            ) {
                pendingDownload = PendingDownload(url, fileName, userAgent, mimeType)
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                    REQUEST_WRITE_STORAGE
                )
            } else {
                startDownload(url, fileName, userAgent, mimeType)
            }
        }
    }

    // Запускает загрузку через системный DownloadManager.
    // Передаём куки и User-Agent — без них многие сайты отдают ошибку вместо файла.
    private fun startDownload(url: String, fileName: String, userAgent: String?, mimeType: String?) {
        try {
            val request = DownloadManager.Request(Uri.parse(url))
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            request.setTitle(fileName)
            request.setAllowedOverMetered(true)
            request.setAllowedOverRoaming(true)

            val cookie = CookieManager.getInstance().getCookie(url)
            if (!cookie.isNullOrBlank()) {
                request.addRequestHeader("cookie", cookie)
            }
            if (!userAgent.isNullOrBlank()) {
                request.addRequestHeader("User-Agent", userAgent)
            }
            if (!mimeType.isNullOrBlank() && mimeType != "application/octet-stream") {
                request.setMimeType(mimeType)
            }

            val downloadManager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val systemId = downloadManager.enqueue(request)

            lifecycleScope.launch {
                db.downloadDao().insert(
                    DownloadItem(
                        fileName = fileName,
                        url = url,
                        timestamp = System.currentTimeMillis(),
                        systemDownloadId = systemId,
                        status = getString(R.string.status_running)
                    )
                )
            }
            Toast.makeText(this, getString(R.string.download_started, fileName), Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось начать загрузку: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_WRITE_STORAGE &&
            grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            pendingDownload?.let { startDownload(it.url, it.fileName, it.userAgent, it.mimeType) }
        }
        pendingDownload = null
    }

    private fun setupAddressBar() {
        addressInput.setOnEditorActionListener { _, actionId, event ->
            val isEnter = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER
            if (actionId == EditorInfo.IME_ACTION_GO || isEnter) {
                navigateFromInput(addressInput.text.toString())
                suggestionsList.visibility = View.GONE
                true
            } else {
                false
            }
        }

        addressInput.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                showTopBar()
                querySuggestions(addressInput.text.toString())
            } else {
                suggestionsList.visibility = View.GONE
            }
        }

        addressInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (addressInput.hasFocus()) {
                    querySuggestions(s?.toString() ?: "")
                }
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    }

    private fun setupSuggestions() {
        suggestionsAdapter = SuggestionsAdapter(emptyList()) { item ->
            addressInput.setText(item.url)
            suggestionsList.visibility = View.GONE
            webView.loadUrl(item.url)
            addressInput.clearFocus()
        }
        suggestionsList.layoutManager = LinearLayoutManager(this)
        suggestionsList.adapter = suggestionsAdapter
    }

    private fun querySuggestions(text: String) {
        lifecycleScope.launch {
            val results = if (text.isBlank()) {
                db.historyDao().getAll().take(5)
            } else {
                db.historyDao().search(text.trim())
            }
            suggestionsAdapter.update(results)
            suggestionsList.visibility = if (results.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    // Свайп сверху вниз (когда страница уже наверху) -> перезагрузка страницы
    private fun setupSwipeRefresh() {
        swipeRefresh.setOnRefreshListener {
            showTopBar()
            webView.reload()
        }
    }

    // Скрываем верхнюю панель при скролле вниз по странице, показываем при скролле вверх
    private fun setupHideOnScroll() {
        webView.setOnScrollChangeListener { _, _, scrollY, _, oldScrollY ->
            when {
                scrollY <= 0 -> showTopBar()
                scrollY > oldScrollY + 5 -> hideTopBar()
                scrollY < oldScrollY - 5 -> showTopBar()
            }
        }
    }

    private fun hideTopBar() {
        if (topBarHidden || addressInput.hasFocus()) return
        topBarHidden = true
        topBar.animate().translationY(-topBar.height.toFloat()).setDuration(200).start()
    }

    private fun showTopBar() {
        if (!topBarHidden) return
        topBarHidden = false
        topBar.animate().translationY(0f).setDuration(200).start()
    }

    private fun setupButtons() {
        findViewById<View>(R.id.btnBack).setOnClickListener {
            if (webView.canGoBack()) webView.goBack()
        }
        findViewById<View>(R.id.btnForward).setOnClickListener {
            if (webView.canGoForward()) webView.goForward()
        }

        btnBookmarkToggle.setOnClickListener {
            toggleBookmark()
        }

        findViewById<View>(R.id.btnMenu).setOnClickListener { anchor ->
            val popup = PopupMenu(this, anchor)
            popup.menuInflater.inflate(R.menu.menu_main, popup.menu)
            popup.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.menu_bookmarks -> {
                        startActivity(Intent(this, BookmarksActivity::class.java)); true
                    }
                    R.id.menu_downloads -> {
                        startActivity(Intent(this, DownloadsActivity::class.java)); true
                    }
                    R.id.menu_settings -> {
                        startActivity(Intent(this, SettingsActivity::class.java)); true
                    }
                    R.id.menu_default_browser -> {
                        openDefaultAppsSettings(); true
                    }
                    else -> false
                }
            }
            popup.show()
        }
    }

    // Открывает системный экран, где можно выбрать браузер по умолчанию.
    // Android не позволяет приложению назначить себя браузером по умолчанию само —
    // это всегда явное действие пользователя в настройках.
    private fun openDefaultAppsSettings() {
        try {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                Intent(android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)
            } else {
                Intent(android.provider.Settings.ACTION_SETTINGS)
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Открой Настройки -> Приложения -> Браузер по умолчанию вручную", Toast.LENGTH_LONG).show()
        }
    }

    // Определяет, ввёл ли пользователь адрес сайта или поисковый запрос
    private fun navigateFromInput(rawInput: String) {
        val input = rawInput.trim()
        if (input.isEmpty()) return

        val url = when {
            Patterns.WEB_URL.matcher(input).matches() && !input.contains(" ") -> {
                if (input.startsWith("http://") || input.startsWith("https://")) input
                else "https://$input"
            }
            (input.startsWith("http://") || input.startsWith("https://")) -> input
            else -> Prefs.buildSearchUrl(this, input)
        }
        webView.loadUrl(url)
    }

    private fun saveHistory(url: String, title: String) {
        if (url.isBlank() || url == "about:blank") return
        lifecycleScope.launch {
            db.historyDao().insert(HistoryItem(url = url, title = title, timestamp = System.currentTimeMillis()))
        }
    }

    private fun updateBookmarkIcon(url: String) {
        lifecycleScope.launch {
            val existing = db.bookmarkDao().findByUrl(url)
            btnBookmarkToggle.setImageResource(
                if (existing != null) R.drawable.ic_star_filled else R.drawable.ic_star_outline
            )
        }
    }

    // Добавление закладки: спрашиваем название папки (по умолчанию "Общие"),
    // чтобы закладки можно было удобно сортировать
    private fun toggleBookmark() {
        val url = webView.url ?: return
        val title = webView.title ?: url
        lifecycleScope.launch {
            val existing = db.bookmarkDao().findByUrl(url)
            if (existing != null) {
                db.bookmarkDao().delete(existing)
                btnBookmarkToggle.setImageResource(R.drawable.ic_star_outline)
                Toast.makeText(this@MainActivity, R.string.bookmark_removed, Toast.LENGTH_SHORT).show()
            } else {
                showFolderDialog(url, title)
            }
        }
    }

    private fun showFolderDialog(url: String, title: String) {
        val input = EditText(this)
        input.setText(DEFAULT_FOLDER)
        input.setSelection(input.text.length)
        input.setTextColor(getColor(R.color.text_primary))
        val padding = (16 * resources.displayMetrics.density).toInt()
        input.setPadding(padding, padding, padding, padding)

        AlertDialog.Builder(this)
            .setTitle(R.string.bookmark_folder_prompt)
            .setView(input)
            .setPositiveButton(R.string.add) { _, _ ->
                val folder = input.text.toString().trim().ifBlank { DEFAULT_FOLDER }
                lifecycleScope.launch {
                    db.bookmarkDao().insert(
                        Bookmark(url = url, title = title, timestamp = System.currentTimeMillis(), folder = folder)
                    )
                    btnBookmarkToggle.setImageResource(R.drawable.ic_star_filled)
                    Toast.makeText(this@MainActivity, R.string.bookmark_added, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // Открытие ссылки из закладок (передаётся через Intent extra "open_url" или как VIEW-интент)
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val url = intent.data?.toString() ?: intent.getStringExtra("open_url")
        url?.let { webView.loadUrl(it) }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
