package com.example.simplebrowser

import android.Manifest
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.Patterns
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.simplebrowser.adapters.SuggestionsAdapter
import com.example.simplebrowser.data.AppDatabase
import com.example.simplebrowser.data.Bookmark
import com.example.simplebrowser.data.DownloadItem
import com.example.simplebrowser.data.HistoryItem
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var addressInput: EditText
    private lateinit var pageProgress: android.widget.ProgressBar
    private lateinit var suggestionsList: androidx.recyclerview.widget.RecyclerView
    private lateinit var btnBookmarkToggle: android.widget.ImageButton

    private lateinit var db: AppDatabase
    private lateinit var suggestionsAdapter: SuggestionsAdapter

    private var pendingDownloadUrl: String? = null
    private var pendingDownloadFileName: String? = null

    companion object {
        private const val REQUEST_WRITE_STORAGE = 100
        private const val HOME_URL = "https://www.google.com"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = AppDatabase.getInstance(this)

        webView = findViewById(R.id.webView)
        addressInput = findViewById(R.id.addressInput)
        pageProgress = findViewById(R.id.pageProgress)
        suggestionsList = findViewById(R.id.suggestionsList)
        btnBookmarkToggle = findViewById(R.id.btnBookmarkToggle)

        setupWebView()
        setupAddressBar()
        setupSuggestions()
        setupButtons()

        val openUrl = intent.getStringExtra("open_url")
        webView.loadUrl(openUrl ?: HOME_URL)
    }

    private fun setupWebView() {
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadWithOverviewMode = true
        webView.settings.useWideViewPort = true
        webView.settings.setSupportZoom(true)
        webView.settings.builtInZoomControls = true
        webView.settings.displayZoomControls = false

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                view.loadUrl(url)
                return true
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                addressInput.setText(url)
                pageProgress.visibility = View.GONE
                updateBookmarkIcon(url)
                saveHistory(url, view.title ?: "")
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                if (newProgress in 1..99) {
                    pageProgress.visibility = View.VISIBLE
                    pageProgress.progress = newProgress
                } else {
                    pageProgress.visibility = View.GONE
                }
            }
        }

        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, contentLength ->
            val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED
            ) {
                pendingDownloadUrl = url
                pendingDownloadFileName = fileName
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                    REQUEST_WRITE_STORAGE
                )
            } else {
                startDownload(url, fileName)
            }
        }
    }

    private fun startDownload(url: String, fileName: String) {
        val request = DownloadManager.Request(Uri.parse(url))
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
        request.setTitle(fileName)
        request.setMimeType(null)

        val downloadManager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val systemId = downloadManager.enqueue(request)

        lifecycleScope.launch {
            db.downloadDao().insert(
                DownloadItem(
                    fileName = fileName,
                    url = url,
                    timestamp = System.currentTimeMillis(),
                    systemDownloadId = systemId,
                    status = "В процессе"
                )
            )
        }
        Toast.makeText(this, getString(R.string.download_started, fileName), Toast.LENGTH_SHORT).show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_WRITE_STORAGE &&
            grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            val url = pendingDownloadUrl
            val name = pendingDownloadFileName
            if (url != null && name != null) {
                startDownload(url, name)
            }
        }
        pendingDownloadUrl = null
        pendingDownloadFileName = null
    }

    private fun setupAddressBar() {
        addressInput.setOnEditorActionListener { _, actionId, event ->
            val isEnter = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER
            if (actionId == EditorInfo.IME_ACTION_GO || isEnter) {
                navigateFromInput(addressInput.text.toString())
                suggestionsList.visibility = View.GONE
                true
            } else {
                false
            }
        }

        addressInput.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                querySuggestions(addressInput.text.toString())
            } else {
                suggestionsList.visibility = View.GONE
            }
        }

        addressInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (addressInput.hasFocus()) {
                    querySuggestions(s?.toString() ?: "")
                }
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    }

    private fun setupSuggestions() {
        suggestionsAdapter = SuggestionsAdapter(emptyList()) { item ->
            addressInput.setText(item.url)
            suggestionsList.visibility = View.GONE
            webView.loadUrl(item.url)
            addressInput.clearFocus()
        }
        suggestionsList.layoutManager = LinearLayoutManager(this)
        suggestionsList.adapter = suggestionsAdapter
    }

    private fun querySuggestions(text: String) {
        lifecycleScope.launch {
            val results = if (text.isBlank()) {
                db.historyDao().getAll().take(5)
            } else {
                db.historyDao().search(text.trim())
            }
            suggestionsAdapter.update(results)
            suggestionsList.visibility = if (results.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    private fun setupButtons() {
        findViewById<View>(R.id.btnBack).setOnClickListener {
            if (webView.canGoBack()) webView.goBack()
        }
        findViewById<View>(R.id.btnForward).setOnClickListener {
            if (webView.canGoForward()) webView.goForward()
        }

        btnBookmarkToggle.setOnClickListener {
            toggleBookmark()
        }

        findViewById<View>(R.id.btnMenu).setOnClickListener { anchor ->
            val popup = PopupMenu(this, anchor)
            popup.menuInflater.inflate(R.menu.menu_main, popup.menu)
            popup.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.menu_bookmarks -> {
                        startActivity(Intent(this, BookmarksActivity::class.java)); true
                    }
                    R.id.menu_downloads -> {
                        startActivity(Intent(this, DownloadsActivity::class.java)); true
                    }
                    R.id.menu_settings -> {
                        startActivity(Intent(this, SettingsActivity::class.java)); true
                    }
                    else -> false
                }
            }
            popup.show()
        }
    }

    // Определяет, ввёл ли пользователь адрес сайта или поисковый запрос
    private fun navigateFromInput(rawInput: String) {
        val input = rawInput.trim()
        if (input.isEmpty()) return

        val url = when {
            Patterns.WEB_URL.matcher(input).matches() && !input.contains(" ") -> {
                if (input.startsWith("http://") || input.startsWith("https://")) input
                else "https://$input"
            }
            (input.startsWith("http://") || input.startsWith("https://")) -> input
            else -> Prefs.buildSearchUrl(this, input)
        }
        webView.loadUrl(url)
    }

    private fun saveHistory(url: String, title: String) {
        if (url.isBlank() || url == "about:blank") return
        lifecycleScope.launch {
            db.historyDao().insert(HistoryItem(url = url, title = title, timestamp = System.currentTimeMillis()))
        }
    }

    private fun updateBookmarkIcon(url: String) {
        lifecycleScope.launch {
            val existing = db.bookmarkDao().findByUrl(url)
            btnBookmarkToggle.setImageResource(
                if (existing != null) R.drawable.ic_star_filled else R.drawable.ic_star_outline
            )
        }
    }

    private fun toggleBookmark() {
        val url = webView.url ?: return
        val title = webView.title ?: url
        lifecycleScope.launch {
            val existing = db.bookmarkDao().findByUrl(url)
            if (existing != null) {
                db.bookmarkDao().delete(existing)
                btnBookmarkToggle.setImageResource(R.drawable.ic_star_outline)
                Toast.makeText(this@MainActivity, R.string.bookmark_removed, Toast.LENGTH_SHORT).show()
            } else {
                db.bookmarkDao().insert(Bookmark(url = url, title = title, timestamp = System.currentTimeMillis()))
                btnBookmarkToggle.setImageResource(R.drawable.ic_star_filled)
                Toast.makeText(this@MainActivity, R.string.bookmark_added, Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Открытие ссылки из закладок (передаётся через Intent extra "open_url")
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.getStringExtra("open_url")?.let { webView.loadUrl(it) }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
