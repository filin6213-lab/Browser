package com.example.simplebrowser

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.lifecycle.LifecycleCoroutineScope
import com.example.simplebrowser.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class DownloadCompleteReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val downloadId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
        if (downloadId == -1L) return

        val db = AppDatabase.getInstance(context)
        val status = context.getString(R.string.status_success)
        CoroutineScope(Dispatchers.IO).launch {
            db.downloadDao().updateStatusBySystemId(downloadId, status)
        }
    }
}
