package com.example.simplebrowser

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.widget.RadioGroup

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        findViewById<Toolbar>(R.id.toolbar).setNavigationOnClickListener { finish() }

        val group = findViewById<RadioGroup>(R.id.searchEngineGroup)
        val engineGoogle = findViewById<android.widget.RadioButton>(R.id.engineGoogle)
        val engineDuckDuckGo = findViewById<android.widget.RadioButton>(R.id.engineDuckDuckGo)
        val engineStartpage = findViewById<android.widget.RadioButton>(R.id.engineStartpage)

        when (Prefs.getSearchEngine(this)) {
            Prefs.ENGINE_DUCKDUCKGO -> engineDuckDuckGo.isChecked = true
            Prefs.ENGINE_STARTPAGE -> engineStartpage.isChecked = true
            else -> engineGoogle.isChecked = true
        }

        group.setOnCheckedChangeListener { _, checkedId ->
            val engine = when (checkedId) {
                R.id.engineDuckDuckGo -> Prefs.ENGINE_DUCKDUCKGO
                R.id.engineStartpage -> Prefs.ENGINE_STARTPAGE
                else -> Prefs.ENGINE_GOOGLE
            }
            Prefs.setSearchEngine(this, engine)
        }
    }
}
