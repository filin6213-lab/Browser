package com.example.simplebrowser

import android.app.AlertDialog
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Switch
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import com.example.simplebrowser.data.AppDatabase
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        db = AppDatabase.getInstance(this)

        findViewById<Toolbar>(R.id.toolbar).setNavigationOnClickListener { finish() }

        setupSearchEngine()
        setupTheme()
        setupToggles()
        setupClearButtons()
    }

    private fun setupSearchEngine() {
        val group = findViewById<RadioGroup>(R.id.searchEngineGroup)
        val engineGoogle = findViewById<RadioButton>(R.id.engineGoogle)
        val engineDuckDuckGo = findViewById<RadioButton>(R.id.engineDuckDuckGo)
        val engineStartpage = findViewById<RadioButton>(R.id.engineStartpage)

        when (Prefs.getSearchEngine(this)) {
            Prefs.ENGINE_DUCKDUCKGO -> engineDuckDuckGo.isChecked = true
            Prefs.ENGINE_STARTPAGE -> engineStartpage.isChecked = true
            else -> engineGoogle.isChecked = true
        }

        group.setOnCheckedChangeListener { _, checkedId ->
            val engine = when (checkedId) {
                R.id.engineDuckDuckGo -> Prefs.ENGINE_DUCKDUCKGO
                R.id.engineStartpage -> Prefs.ENGINE_STARTPAGE
                else -> Prefs.ENGINE_GOOGLE
            }
            Prefs.setSearchEngine(this, engine)
        }
    }

    private fun setupTheme() {
        val group = findViewById<RadioGroup>(R.id.themeGroup)
        val themeButtons = mapOf(
            R.id.themeBlue to Themes.BLUE.key,
            R.id.themeDark to Themes.DARK.key,
            R.id.themeGreen to Themes.GREEN.key,
            R.id.themePurple to Themes.PURPLE.key,
            R.id.themeSunset to Themes.SUNSET.key
        )

        val currentTheme = Prefs.getTheme(this)
        themeButtons.entries.find { it.value == currentTheme }?.let {
            findViewById<RadioButton>(it.key).isChecked = true
        }

        group.setOnCheckedChangeListener { _, checkedId ->
            themeButtons[checkedId]?.let { Prefs.setTheme(this, it) }
            // Тема применится в MainActivity.onResume() при возврате назад
        }
    }

    private fun setupToggles() {
        val switchJs = findViewById<Switch>(R.id.switchJs)
        val switchSaveHistory = findViewById<Switch>(R.id.switchSaveHistory)
        val switchBlockPopups = findViewById<Switch>(R.id.switchBlockPopups)

        switchJs.isChecked = Prefs.isJsEnabled(this)
        switchSaveHistory.isChecked = Prefs.isSaveHistoryEnabled(this)
        switchBlockPopups.isChecked = Prefs.isBlockPopupsEnabled(this)

        switchJs.setOnCheckedChangeListener { _, checked -> Prefs.setJsEnabled(this, checked) }
        switchSaveHistory.setOnCheckedChangeListener { _, checked -> Prefs.setSaveHistoryEnabled(this, checked) }
        switchBlockPopups.setOnCheckedChangeListener { _, checked -> Prefs.setBlockPopupsEnabled(this, checked) }
    }

    private fun setupClearButtons() {
        findViewById<Button>(R.id.btnClearHistory).setOnClickListener {
            confirmClear { lifecycleScope.launch { db.historyDao().clear() } }
        }
        findViewById<Button>(R.id.btnClearBookmarks).setOnClickListener {
            confirmClear { lifecycleScope.launch { db.bookmarkDao().clear() } }
        }
        findViewById<Button>(R.id.btnClearDownloads).setOnClickListener {
            confirmClear { lifecycleScope.launch { db.downloadDao().clear() } }
        }
    }

    private fun confirmClear(action: () -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(R.string.clear_confirm_title)
            .setMessage(R.string.clear_confirm_message)
            .setPositiveButton("Очистить") { _, _ ->
                action()
                android.widget.Toast.makeText(this, R.string.cleared, android.widget.Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
