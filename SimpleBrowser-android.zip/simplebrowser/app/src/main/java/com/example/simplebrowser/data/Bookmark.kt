package com.example.simplebrowser.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Delete
import androidx.room.Update

const val DEFAULT_FOLDER = "Общие"

@Entity(tableName = "bookmarks")
data class Bookmark(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val title: String,
    val timestamp: Long,
    val folder: String = DEFAULT_FOLDER
)

@Dao
interface BookmarkDao {
    @Insert
    suspend fun insert(item: Bookmark)

    @Query("SELECT * FROM bookmarks ORDER BY folder ASC, timestamp DESC")
    suspend fun getAll(): List<Bookmark>

    @Query("SELECT DISTINCT folder FROM bookmarks ORDER BY folder ASC")
    suspend fun getAllFolders(): List<String>

    @Query("SELECT * FROM bookmarks WHERE url = :url LIMIT 1")
    suspend fun findByUrl(url: String): Bookmark?

    @Update
    suspend fun update(item: Bookmark)

    @Delete
    suspend fun delete(item: Bookmark)

    @Query("DELETE FROM bookmarks WHERE url = :url")
    suspend fun deleteByUrl(url: String)
}
