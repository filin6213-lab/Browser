package com.example.simplebrowser.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Delete

@Entity(tableName = "history")
data class HistoryItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val title: String,
    val timestamp: Long
)

@Dao
interface HistoryDao {
    @Insert
    suspend fun insert(item: HistoryItem)

    // Последние записи, подходящие под введённый текст (для подсказок под адресной строкой)
    @Query("SELECT * FROM history WHERE url LIKE '%' || :query || '%' OR title LIKE '%' || :query || '%' ORDER BY timestamp DESC LIMIT 5")
    suspend fun search(query: String): List<HistoryItem>

    @Query("SELECT * FROM history ORDER BY timestamp DESC LIMIT 100")
    suspend fun getAll(): List<HistoryItem>

    @Delete
    suspend fun delete(item: HistoryItem)

    @Query("DELETE FROM history")
    suspend fun clear()
}
